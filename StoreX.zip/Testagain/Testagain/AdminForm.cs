﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testagain
{
    public partial class AdminForm : Form
    {
        SqlConnection conn = new SqlConnection(@"Server=SHIRO\SQLEXPRESS;Database=StoreXDB;Trusted_Connection=True;");
        public AdminForm()
        {
            InitializeComponent();
        }

        private void AdminForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
            LoadEmployees();
            LoadCustomers();
            LoadUserAccounts();

            // === CODE MỚI ===
            // Tải dữ liệu cho các ComboBox trong tab tạo hóa đơn
            LoadInvoiceCustomers();
            LoadInvoiceProducts();
        }
        private void LoadProducts()
        {
            lvProduct.Items.Clear();
            string sql = "SELECT * FROM Products";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["ProductID"].ToString());
                item.SubItems.Add(reader["ProductName"].ToString());
                item.SubItems.Add(reader["Price"].ToString());
                item.SubItems.Add(reader["Quantity"].ToString());
                lvProduct.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }

        private void btnProductAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO Products(ProductName, Price, Quantity) VALUES(@name, @price, @qty)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", txtProductName.Text);
            cmd.Parameters.AddWithValue("@price", decimal.Parse(txtProductPrice.Text));
            cmd.Parameters.AddWithValue("@qty", int.Parse(txtProductQuantity.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadProducts();
        }
        private void btnProductEdit_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE Products SET ProductName=@name, Price=@price, Quantity=@qty WHERE ProductID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtProductID.Text));
            cmd.Parameters.AddWithValue("@name", txtProductName.Text);
            cmd.Parameters.AddWithValue("@price", decimal.Parse(txtProductPrice.Text));
            cmd.Parameters.AddWithValue("@qty", int.Parse(txtProductQuantity.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadProducts();
        }

        private void btnProductDelte_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Products WHERE ProductID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtProductID.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadProducts();
        }
        private void LoadEmployees()
        {
            listViewEmployees.Items.Clear();
            string sql = "SELECT * FROM Employees";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["EmployeeID"].ToString());
                item.SubItems.Add(reader["EmployeeName"].ToString());
                item.SubItems.Add(reader["Role"].ToString());
                listViewEmployees.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }

        private void btnEmployeesAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO Employees(EmployeeName, Role) VALUES(@name, @role)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", txtEmployeesName.Text);
            cmd.Parameters.AddWithValue("@role", txtEmployeesPosition.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadEmployees();
        }

        private void btnEmployeesEdit_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE Employees SET EmployeeName=@name, Role=@role WHERE EmployeeID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtEmployeesID.Text));
            cmd.Parameters.AddWithValue("@name", txtEmployeesName.Text);
            cmd.Parameters.AddWithValue("@role", txtEmployeesPosition.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadEmployees();
        }

        private void btnEmployeesDelete_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Employees WHERE EmployeeID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtEmployeesID.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadEmployees();
        }
        private void LoadCustomers()
        {
            listViewCustomers.Items.Clear();
            string sql = "SELECT * FROM Customers";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["CustomerID"].ToString());
                item.SubItems.Add(reader["CustomerName"].ToString());
                item.SubItems.Add(reader["Phone"].ToString());
                item.SubItems.Add(reader["Address"].ToString());
                listViewCustomers.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }

        private void btnCustomerAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO Customers(CustomerName, Phone, Address) VALUES(@name, @phone, @address)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@phone", txtCustomerPhone.Text);
            cmd.Parameters.AddWithValue("@address", txtCustomerAddress.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }

        private void btnCustomerEdit_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE Customers SET CustomerName=@name, Phone=@phone, Address=@address WHERE CustomerID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtCustomerID.Text));
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@phone", txtCustomerPhone.Text);
            cmd.Parameters.AddWithValue("@address", txtCustomerAddress.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }

        private void btnCustomerDelete_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Customers WHERE CustomerID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtCustomerID.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }
        private void LoadUserAccounts()
        {
            listViewUserAccounts.Items.Clear();
            string sql = "SELECT * FROM UserAccounts";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["UserID"].ToString());
                item.SubItems.Add(reader["EmployeeID"].ToString());
                item.SubItems.Add(reader["Username"].ToString());
                item.SubItems.Add(reader["Password"].ToString());
                listViewUserAccounts.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }

        private void btnUserAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO UserAccounts(EmployeeID, Username, Password) VALUES(@eid, @username, @pass)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@eid", int.Parse(txtUAEmployeeID.Text));
            cmd.Parameters.AddWithValue("@username", txtUAUsername.Text);
            cmd.Parameters.AddWithValue("@pass", txtUAPassword.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadUserAccounts();
        }

        private void btnUserDelete_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM UserAccounts WHERE UserID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtUAID.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadUserAccounts();
        }
        private void LoadInvoiceCustomers()
        {
            var customerList = new List<KeyValuePair<int, string>>();
            string sql = "SELECT CustomerID, CustomerName FROM Customers ORDER BY CustomerName";
            SqlCommand cmd = new SqlCommand(sql, conn);

            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    customerList.Add(new KeyValuePair<int, string>(
                        (int)reader["CustomerID"],
                        reader["CustomerName"].ToString()
                    ));
                }
                reader.Close();

                // Gán dữ liệu cho ComboBox
                cmbCustomers.DataSource = customerList;
                cmbCustomers.DisplayMember = "Value"; // Hiển thị Tên
                cmbCustomers.ValueMember = "Key";     // Giá trị thực là ID
            }
            catch (Exception ex) { MessageBox.Show("Lỗi tải danh sách khách hàng: " + ex.Message); }
            finally { if (conn.State == ConnectionState.Open) conn.Close(); }
        }
        private void LoadInvoiceProducts()
        {
            var productList = new List<KeyValuePair<int, string>>();
            string sql = "SELECT ProductID, ProductName FROM Products ORDER BY ProductName";
            SqlCommand cmd = new SqlCommand(sql, conn);

            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                while (reader.Read())
                {
                    productList.Add(new KeyValuePair<int, string>(
                        (int)reader["ProductID"],
                        reader["ProductName"].ToString()
                    ));
                }
                reader.Close();

                // Gán dữ liệu cho ComboBox
                cmbProducts.DataSource = productList;
                cmbProducts.DisplayMember = "Value"; // Hiển thị Tên
                cmbProducts.ValueMember = "Key";     // Giá trị thực là ID
            }
            catch (Exception ex) { MessageBox.Show("Lỗi tải danh sách sản phẩm: " + ex.Message); }
            finally { if (conn.State == ConnectionState.Open) conn.Close(); }
        }
        private void btnAddItem_Click(object sender, EventArgs e)
        {
            if (cmbProducts.SelectedValue == null) { MessageBox.Show("Vui lòng chọn một sản phẩm."); return; }
            if (!int.TryParse(txtInvoiceQuantity.Text, out int quantity) || quantity <= 0) { MessageBox.Show("Số lượng phải là một số nguyên dương."); return; }

            int productId = (int)cmbProducts.SelectedValue;
            string productName = cmbProducts.Text;
            decimal price = 0;
            int stock = 0;

            // Lấy giá và số lượng tồn kho từ DB
            string sql = "SELECT Price, Quantity FROM Products WHERE ProductID = @pid";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@pid", productId);
            try
            {
                conn.Open();
                SqlDataReader reader = cmd.ExecuteReader();
                if (reader.Read())
                {
                    price = (decimal)reader["Price"];
                    stock = (int)reader["Quantity"];
                }
                reader.Close();
            }
            catch (Exception ex) { MessageBox.Show("Lỗi lấy thông tin sản phẩm: " + ex.Message); }
            finally { if (conn.State == ConnectionState.Open) conn.Close(); }


            if (quantity > stock) { MessageBox.Show($"Số lượng tồn kho không đủ. Chỉ còn {stock} sản phẩm."); return; }

            // Kiểm tra xem sản phẩm đã có trong giỏ hàng chưa
            foreach (ListViewItem existingItem in listViewInvoiceItems.Items)
            {
                if (int.Parse(existingItem.SubItems[0].Text) == productId)
                {
                    int newQuantity = int.Parse(existingItem.SubItems[2].Text) + quantity;
                    if (newQuantity > stock) { MessageBox.Show($"Tổng số lượng vượt quá tồn kho. Chỉ còn {stock} sản phẩm."); return; }
                    existingItem.SubItems[2].Text = newQuantity.ToString();
                    existingItem.SubItems[4].Text = (newQuantity * price).ToString("N0");
                    return;
                }
            }

            // Nếu chưa có, thêm dòng mới
            ListViewItem item = new ListViewItem(productId.ToString());
            item.SubItems.Add(productName);
            item.SubItems.Add(quantity.ToString());
            item.SubItems.Add(price.ToString("N0"));
            item.SubItems.Add((quantity * price).ToString("N0"));
            listViewInvoiceItems.Items.Add(item);
        }
        private void btnDeleteItem_Click(object sender, EventArgs e)
        {
            if (listViewInvoiceItems.SelectedItems.Count > 0)
            {
                listViewInvoiceItems.SelectedItems[0].Remove();
            }
            else
            {
                MessageBox.Show("Vui lòng chọn một sản phẩm trong hóa đơn để xóa.");
            }
        }

        private void btnCreateInvoice_Click(object sender, EventArgs e)
        {
            if (cmbCustomers.SelectedValue == null) { MessageBox.Show("Vui lòng chọn khách hàng."); return; }
            if (listViewInvoiceItems.Items.Count == 0) { MessageBox.Show("Hóa đơn không có sản phẩm nào."); return; }

            conn.Open(); // Mở kết nối một lần cho toàn bộ giao dịch
            SqlTransaction transaction = conn.BeginTransaction();

            try
            {
                int customerId = (int)cmbCustomers.SelectedValue;
                int employeeId = 1; // Giả sử Admin (ID=1) là người tạo hóa đơn

                // 1. Tạo hóa đơn chính và lấy ID trả về
                string sqlInvoice = "INSERT INTO SalesInvoices(EmployeeID, CustomerID) OUTPUT INSERTED.InvoiceID VALUES(@eid, @cid)";
                SqlCommand cmdInvoice = new SqlCommand(sqlInvoice, conn, transaction);
                cmdInvoice.Parameters.AddWithValue("@eid", employeeId);
                cmdInvoice.Parameters.AddWithValue("@cid", customerId);
                int newInvoiceID = (int)cmdInvoice.ExecuteScalar();

                // 2. Thêm các chi tiết hóa đơn và cập nhật kho
                foreach (ListViewItem item in listViewInvoiceItems.Items)
                {
                    int productId = int.Parse(item.SubItems[0].Text);
                    int quantity = int.Parse(item.SubItems[2].Text);
                    decimal unitPrice = decimal.Parse(item.SubItems[3].Text.Replace(",", ""));

                    // Thêm vào SalesDetails
                    string sqlDetail = "INSERT INTO SalesDetails(InvoiceID, ProductID, Quantity, UnitPrice) VALUES(@inv, @pid, @qty, @price)";
                    SqlCommand cmdDetail = new SqlCommand(sqlDetail, conn, transaction);
                    cmdDetail.Parameters.AddWithValue("@inv", newInvoiceID);
                    cmdDetail.Parameters.AddWithValue("@pid", productId);
                    cmdDetail.Parameters.AddWithValue("@qty", quantity);
                    cmdDetail.Parameters.AddWithValue("@price", unitPrice);
                    cmdDetail.ExecuteNonQuery();

                    // Cập nhật tồn kho
                    string sqlUpdateStock = "UPDATE Products SET Quantity = Quantity - @qty WHERE ProductID = @pid";
                    SqlCommand cmdUpdateStock = new SqlCommand(sqlUpdateStock, conn, transaction);
                    cmdUpdateStock.Parameters.AddWithValue("@qty", quantity);
                    cmdUpdateStock.Parameters.AddWithValue("@pid", productId);
                    cmdUpdateStock.ExecuteNonQuery();
                }

                // Nếu mọi thứ thành công, xác nhận giao dịch
                transaction.Commit();
                MessageBox.Show("Tạo hóa đơn thành công! Mã hóa đơn: " + newInvoiceID);

                // Dọn dẹp form
                listViewInvoiceItems.Items.Clear();
                txtInvoiceQuantity.Clear();
                LoadProducts(); // Tải lại danh sách sản phẩm để cập nhật số lượng tồn kho
            }
            catch (Exception ex)
            {
                // Nếu có lỗi, hủy bỏ mọi thay đổi
                transaction.Rollback();
                MessageBox.Show("Đã xảy ra lỗi, không thể tạo hóa đơn. Chi tiết: " + ex.Message);
            }
            finally
            {
                // Luôn đóng kết nối sau khi hoàn tất
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }
        }
    }
}
