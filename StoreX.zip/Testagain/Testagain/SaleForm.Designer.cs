﻿namespace Testagain
{
    partial class SaleForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            Product = new TabPage();
            lvProduct = new ListView();
            tabPage2 = new TabPage();
            txtCustomerAddress = new TextBox();
            txtCustomerPhone = new TextBox();
            txtCustomerName = new TextBox();
            txtCustomerID = new TextBox();
            btnCustomerDelete = new Button();
            btnCustomerEdit = new Button();
            btnCustomerAdd = new Button();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            lvCustomer = new ListView();
            tabPage1 = new TabPage();
            btnProductEdit = new Button();
            btnProductAdd = new Button();
            btnCreateInvoice = new Button();
            lvSaleInvoice = new ListView();
            ProductID = new TextBox();
            label6 = new Label();
            textBox1 = new TextBox();
            label5 = new Label();
            tabPage3 = new TabPage();
            lvMyOrder = new ListView();
            tabControl1.SuspendLayout();
            Product.SuspendLayout();
            tabPage2.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage3.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(Product);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage3);
            tabControl1.Location = new Point(0, 0);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(801, 451);
            tabControl1.TabIndex = 1;
            // 
            // Product
            // 
            Product.Controls.Add(lvProduct);
            Product.Location = new Point(4, 29);
            Product.Name = "Product";
            Product.Padding = new Padding(3);
            Product.Size = new Size(793, 418);
            Product.TabIndex = 0;
            Product.Text = "Product";
            Product.UseVisualStyleBackColor = true;
            // 
            // lvProduct
            // 
            lvProduct.Location = new Point(46, 101);
            lvProduct.Name = "lvProduct";
            lvProduct.Size = new Size(700, 216);
            lvProduct.TabIndex = 1;
            lvProduct.UseCompatibleStateImageBehavior = false;
            lvProduct.View = View.Tile;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(txtCustomerAddress);
            tabPage2.Controls.Add(txtCustomerPhone);
            tabPage2.Controls.Add(txtCustomerName);
            tabPage2.Controls.Add(txtCustomerID);
            tabPage2.Controls.Add(btnCustomerDelete);
            tabPage2.Controls.Add(btnCustomerEdit);
            tabPage2.Controls.Add(btnCustomerAdd);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label3);
            tabPage2.Controls.Add(label2);
            tabPage2.Controls.Add(label1);
            tabPage2.Controls.Add(lvCustomer);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(793, 418);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Customer";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // txtCustomerAddress
            // 
            txtCustomerAddress.Location = new Point(196, 304);
            txtCustomerAddress.Name = "txtCustomerAddress";
            txtCustomerAddress.Size = new Size(200, 27);
            txtCustomerAddress.TabIndex = 8;
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.Location = new Point(196, 269);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.Size = new Size(200, 27);
            txtCustomerPhone.TabIndex = 8;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(196, 236);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(200, 27);
            txtCustomerName.TabIndex = 8;
            // 
            // txtCustomerID
            // 
            txtCustomerID.Location = new Point(196, 199);
            txtCustomerID.Name = "txtCustomerID";
            txtCustomerID.Size = new Size(200, 27);
            txtCustomerID.TabIndex = 8;
            // 
            // btnCustomerDelete
            // 
            btnCustomerDelete.Location = new Point(476, 361);
            btnCustomerDelete.Name = "btnCustomerDelete";
            btnCustomerDelete.Size = new Size(94, 29);
            btnCustomerDelete.TabIndex = 7;
            btnCustomerDelete.Text = "Delete";
            btnCustomerDelete.UseVisualStyleBackColor = true;
            btnCustomerDelete.Click += btnCustomerDelete_Click;
            // 
            // btnCustomerEdit
            // 
            btnCustomerEdit.Location = new Point(336, 361);
            btnCustomerEdit.Name = "btnCustomerEdit";
            btnCustomerEdit.Size = new Size(94, 29);
            btnCustomerEdit.TabIndex = 6;
            btnCustomerEdit.Text = "Edit";
            btnCustomerEdit.UseVisualStyleBackColor = true;
            btnCustomerEdit.Click += btnCustomerEdit_Click;
            // 
            // btnCustomerAdd
            // 
            btnCustomerAdd.Location = new Point(184, 361);
            btnCustomerAdd.Name = "btnCustomerAdd";
            btnCustomerAdd.Size = new Size(94, 29);
            btnCustomerAdd.TabIndex = 5;
            btnCustomerAdd.Text = "Add";
            btnCustomerAdd.UseVisualStyleBackColor = true;
            btnCustomerAdd.Click += btnCustomerAdd_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(46, 307);
            label4.Name = "label4";
            label4.Size = new Size(65, 20);
            label4.TabIndex = 4;
            label4.Text = "Address:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(46, 272);
            label3.Name = "label3";
            label3.Size = new Size(53, 20);
            label3.TabIndex = 3;
            label3.Text = "Phone:";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(46, 239);
            label2.Name = "label2";
            label2.Size = new Size(52, 20);
            label2.TabIndex = 2;
            label2.Text = "Name:";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(46, 202);
            label1.Name = "label1";
            label1.Size = new Size(90, 20);
            label1.TabIndex = 1;
            label1.Text = "CustomerID:";
            // 
            // lvCustomer
            // 
            lvCustomer.Location = new Point(46, 39);
            lvCustomer.Name = "lvCustomer";
            lvCustomer.Size = new Size(700, 145);
            lvCustomer.TabIndex = 0;
            lvCustomer.UseCompatibleStateImageBehavior = false;
            lvCustomer.View = View.Details;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(btnProductEdit);
            tabPage1.Controls.Add(btnProductAdd);
            tabPage1.Controls.Add(btnCreateInvoice);
            tabPage1.Controls.Add(lvSaleInvoice);
            tabPage1.Controls.Add(ProductID);
            tabPage1.Controls.Add(label6);
            tabPage1.Controls.Add(textBox1);
            tabPage1.Controls.Add(label5);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(793, 418);
            tabPage1.TabIndex = 2;
            tabPage1.Text = "Sales Invoice";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnProductEdit
            // 
            btnProductEdit.Location = new Point(343, 124);
            btnProductEdit.Name = "btnProductEdit";
            btnProductEdit.Size = new Size(94, 29);
            btnProductEdit.TabIndex = 13;
            btnProductEdit.Text = "Edit";
            btnProductEdit.UseVisualStyleBackColor = true;
            // 
            // btnProductAdd
            // 
            btnProductAdd.Location = new Point(237, 124);
            btnProductAdd.Name = "btnProductAdd";
            btnProductAdd.Size = new Size(94, 29);
            btnProductAdd.TabIndex = 13;
            btnProductAdd.Text = "Add";
            btnProductAdd.UseVisualStyleBackColor = true;
            // 
            // btnCreateInvoice
            // 
            btnCreateInvoice.Location = new Point(84, 286);
            btnCreateInvoice.Name = "btnCreateInvoice";
            btnCreateInvoice.Size = new Size(122, 29);
            btnCreateInvoice.TabIndex = 12;
            btnCreateInvoice.Text = "Create Invoice";
            btnCreateInvoice.UseVisualStyleBackColor = true;
            btnCreateInvoice.Click += btnCreateInvoice_Click;
            // 
            // lvSaleInvoice
            // 
            lvSaleInvoice.Location = new Point(84, 159);
            lvSaleInvoice.Name = "lvSaleInvoice";
            lvSaleInvoice.Size = new Size(633, 121);
            lvSaleInvoice.TabIndex = 11;
            lvSaleInvoice.UseCompatibleStateImageBehavior = false;
            lvSaleInvoice.View = View.Details;
            // 
            // ProductID
            // 
            ProductID.Location = new Point(237, 51);
            ProductID.Name = "ProductID";
            ProductID.Size = new Size(200, 27);
            ProductID.TabIndex = 10;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(87, 54);
            label6.Name = "label6";
            label6.Size = new Size(78, 20);
            label6.TabIndex = 9;
            label6.Text = "ProductID:";
            // 
            // textBox1
            // 
            textBox1.Location = new Point(237, 18);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(200, 27);
            textBox1.TabIndex = 10;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(87, 21);
            label5.Name = "label5";
            label5.Size = new Size(90, 20);
            label5.TabIndex = 9;
            label5.Text = "CustomerID:";
            // 
            // tabPage3
            // 
            tabPage3.Controls.Add(lvMyOrder);
            tabPage3.Location = new Point(4, 29);
            tabPage3.Name = "tabPage3";
            tabPage3.Padding = new Padding(3);
            tabPage3.Size = new Size(793, 418);
            tabPage3.TabIndex = 3;
            tabPage3.Text = "My Orders";
            tabPage3.UseVisualStyleBackColor = true;
            // 
            // lvMyOrder
            // 
            lvMyOrder.Location = new Point(38, 93);
            lvMyOrder.Name = "lvMyOrder";
            lvMyOrder.Size = new Size(718, 219);
            lvMyOrder.TabIndex = 0;
            lvMyOrder.UseCompatibleStateImageBehavior = false;
            lvMyOrder.View = View.Details;
            // 
            // SaleForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "SaleForm";
            Text = "SaleForm";
            Load += SaleForm_Load;
            tabControl1.ResumeLayout(false);
            Product.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            tabPage3.ResumeLayout(false);
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage Product;
        private TabPage tabPage2;
        private ListView lvCustomer;
        private TabPage tabPage1;
        private ListView lvProduct;
        private TextBox txtCustomerAddress;
        private TextBox txtCustomerPhone;
        private TextBox txtCustomerName;
        private TextBox txtCustomerID;
        private Button btnCustomerDelete;
        private Button btnCustomerEdit;
        private Button btnCustomerAdd;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TabPage tabPage3;
        private ListView lvMyOrder;
        private Button btnCreateInvoice;
        private ListView lvSaleInvoice;
        private TextBox textBox1;
        private Label label5;
        private Button btnProductEdit;
        private Button btnProductAdd;
        private TextBox ProductID;
        private Label label6;
    }
}