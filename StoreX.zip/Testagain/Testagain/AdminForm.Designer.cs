﻿namespace Testagain
{
    partial class AdminForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            lvProduct = new TabControl();
            Employees = new TabPage();
            listViewEmployees = new ListView();
            btnEmployeesDelete = new Button();
            btnEmployeesEdit = new Button();
            btnEmployeesAdd = new Button();
            txtEmployeesPhone = new TextBox();
            txtEmployeesEmail = new TextBox();
            txtEmployeesPosition = new TextBox();
            txtEmployeesName = new TextBox();
            txtEmployeesID = new TextBox();
            label7 = new Label();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            UserAccounts = new TabPage();
            btnCustomerDelete = new Button();
            btnCustomerEdit = new Button();
            btnCustomerAdd = new Button();
            txtCustomerAddress = new TextBox();
            txtCustomerMail = new TextBox();
            txtCustomerPhone = new TextBox();
            txtCustomerName = new TextBox();
            txtCustomerID = new TextBox();
            label12 = new Label();
            label11 = new Label();
            label10 = new Label();
            label9 = new Label();
            label8 = new Label();
            listViewCustomers = new ListView();
            Customers = new TabPage();
            btnUserDelete = new Button();
            btnUserAdd = new Button();
            txtUAID = new TextBox();
            txtUAEmployeeID = new TextBox();
            txtUAPassword = new TextBox();
            label21 = new Label();
            txtUAUsername = new TextBox();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            listViewUserAccounts = new ListView();
            Products = new TabPage();
            btnProductSearch = new Button();
            btnProductDelte = new Button();
            btnProductEdit = new Button();
            btnProductAdd = new Button();
            txtProductQuantity = new TextBox();
            txtProductPrice = new TextBox();
            txtProductID = new TextBox();
            txtProductName = new TextBox();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            listViewProducts = new ListView();
            tabPage1 = new TabPage();
            btnDeleteItem = new Button();
            btnEditItem = new Button();
            this.btnAddItem = new Button();
            btnCreateInvoice = new Button();
            listViewInvoiceItems = new ListView();
            txtInvoiceQuantity = new TextBox();
            label13 = new Label();
            label23 = new Label();
            label22 = new Label();
            cmbCustomers = new ComboBox();
            cmbProducts = new ComboBox();
            lvProduct.SuspendLayout();
            Employees.SuspendLayout();
            UserAccounts.SuspendLayout();
            Customers.SuspendLayout();
            Products.SuspendLayout();
            tabPage1.SuspendLayout();
            SuspendLayout();
            // 
            // lvProduct
            // 
            lvProduct.Controls.Add(Employees);
            lvProduct.Controls.Add(UserAccounts);
            lvProduct.Controls.Add(Customers);
            lvProduct.Controls.Add(Products);
            lvProduct.Controls.Add(tabPage1);
            lvProduct.Location = new Point(2, 0);
            lvProduct.Name = "lvProduct";
            lvProduct.SelectedIndex = 0;
            lvProduct.Size = new Size(797, 450);
            lvProduct.TabIndex = 3;
            // 
            // Employees
            // 
            Employees.Controls.Add(listViewEmployees);
            Employees.Controls.Add(btnEmployeesDelete);
            Employees.Controls.Add(btnEmployeesEdit);
            Employees.Controls.Add(btnEmployeesAdd);
            Employees.Controls.Add(txtEmployeesPhone);
            Employees.Controls.Add(txtEmployeesEmail);
            Employees.Controls.Add(txtEmployeesPosition);
            Employees.Controls.Add(txtEmployeesName);
            Employees.Controls.Add(txtEmployeesID);
            Employees.Controls.Add(label7);
            Employees.Controls.Add(label6);
            Employees.Controls.Add(label5);
            Employees.Controls.Add(label4);
            Employees.Controls.Add(label3);
            Employees.Controls.Add(label2);
            Employees.Controls.Add(label1);
            Employees.Location = new Point(4, 29);
            Employees.Name = "Employees";
            Employees.Padding = new Padding(3);
            Employees.Size = new Size(789, 417);
            Employees.TabIndex = 0;
            Employees.Text = "Employees";
            Employees.UseVisualStyleBackColor = true;
            // 
            // listViewEmployees
            // 
            listViewEmployees.Location = new Point(29, 258);
            listViewEmployees.Name = "listViewEmployees";
            listViewEmployees.Size = new Size(717, 138);
            listViewEmployees.TabIndex = 17;
            listViewEmployees.UseCompatibleStateImageBehavior = false;
            listViewEmployees.View = View.Details;
            // 
            // btnEmployeesDelete
            // 
            btnEmployeesDelete.Location = new Point(627, 156);
            btnEmployeesDelete.Name = "btnEmployeesDelete";
            btnEmployeesDelete.Size = new Size(94, 29);
            btnEmployeesDelete.TabIndex = 15;
            btnEmployeesDelete.Text = "Delete";
            btnEmployeesDelete.UseVisualStyleBackColor = true;
            btnEmployeesDelete.Click += btnEmployeesDelete_Click;
            // 
            // btnEmployeesEdit
            // 
            btnEmployeesEdit.Location = new Point(627, 214);
            btnEmployeesEdit.Name = "btnEmployeesEdit";
            btnEmployeesEdit.Size = new Size(94, 29);
            btnEmployeesEdit.TabIndex = 13;
            btnEmployeesEdit.Text = "Edit";
            btnEmployeesEdit.UseVisualStyleBackColor = true;
            btnEmployeesEdit.Click += btnEmployeesEdit_Click;
            // 
            // btnEmployeesAdd
            // 
            btnEmployeesAdd.Location = new Point(627, 100);
            btnEmployeesAdd.Name = "btnEmployeesAdd";
            btnEmployeesAdd.Size = new Size(94, 29);
            btnEmployeesAdd.TabIndex = 12;
            btnEmployeesAdd.Text = "Add";
            btnEmployeesAdd.UseVisualStyleBackColor = true;
            btnEmployeesAdd.Click += btnEmployeesAdd_Click;
            // 
            // txtEmployeesPhone
            // 
            txtEmployeesPhone.Location = new Point(368, 126);
            txtEmployeesPhone.Name = "txtEmployeesPhone";
            txtEmployeesPhone.Size = new Size(174, 27);
            txtEmployeesPhone.TabIndex = 11;
            // 
            // txtEmployeesEmail
            // 
            txtEmployeesEmail.Location = new Point(368, 82);
            txtEmployeesEmail.Name = "txtEmployeesEmail";
            txtEmployeesEmail.Size = new Size(174, 27);
            txtEmployeesEmail.TabIndex = 10;
            // 
            // txtEmployeesPosition
            // 
            txtEmployeesPosition.Location = new Point(99, 171);
            txtEmployeesPosition.Name = "txtEmployeesPosition";
            txtEmployeesPosition.Size = new Size(174, 27);
            txtEmployeesPosition.TabIndex = 9;
            // 
            // txtEmployeesName
            // 
            txtEmployeesName.Location = new Point(99, 126);
            txtEmployeesName.Name = "txtEmployeesName";
            txtEmployeesName.Size = new Size(174, 27);
            txtEmployeesName.TabIndex = 8;
            // 
            // txtEmployeesID
            // 
            txtEmployeesID.Location = new Point(99, 81);
            txtEmployeesID.Name = "txtEmployeesID";
            txtEmployeesID.Size = new Size(174, 27);
            txtEmployeesID.TabIndex = 7;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(304, 142);
            label7.Name = "label7";
            label7.Size = new Size(50, 20);
            label7.TabIndex = 6;
            label7.Text = "Phone";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Location = new Point(304, 98);
            label6.Name = "label6";
            label6.Size = new Size(46, 20);
            label6.TabIndex = 5;
            label6.Text = "Email";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Location = new Point(35, 187);
            label5.Name = "label5";
            label5.Size = new Size(61, 20);
            label5.TabIndex = 4;
            label5.Text = "Position";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(35, 142);
            label4.Name = "label4";
            label4.Size = new Size(49, 20);
            label4.TabIndex = 3;
            label4.Text = "Name";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(35, 97);
            label3.Name = "label3";
            label3.Size = new Size(44, 20);
            label3.TabIndex = 2;
            label3.Text = "Code";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(592, 58);
            label2.Name = "label2";
            label2.Size = new Size(31, 20);
            label2.TabIndex = 1;
            label2.Text = "List";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(61, 47);
            label1.Name = "label1";
            label1.Size = new Size(139, 20);
            label1.TabIndex = 0;
            label1.Text = "Employees manage";
            // 
            // UserAccounts
            // 
            UserAccounts.Controls.Add(btnCustomerDelete);
            UserAccounts.Controls.Add(btnCustomerEdit);
            UserAccounts.Controls.Add(btnCustomerAdd);
            UserAccounts.Controls.Add(txtCustomerAddress);
            UserAccounts.Controls.Add(txtCustomerMail);
            UserAccounts.Controls.Add(txtCustomerPhone);
            UserAccounts.Controls.Add(txtCustomerName);
            UserAccounts.Controls.Add(txtCustomerID);
            UserAccounts.Controls.Add(label12);
            UserAccounts.Controls.Add(label11);
            UserAccounts.Controls.Add(label10);
            UserAccounts.Controls.Add(label9);
            UserAccounts.Controls.Add(label8);
            UserAccounts.Controls.Add(listViewCustomers);
            UserAccounts.Location = new Point(4, 29);
            UserAccounts.Name = "UserAccounts";
            UserAccounts.Padding = new Padding(3);
            UserAccounts.Size = new Size(789, 417);
            UserAccounts.TabIndex = 1;
            UserAccounts.Text = "Customer";
            UserAccounts.UseVisualStyleBackColor = true;
            // 
            // btnCustomerDelete
            // 
            btnCustomerDelete.Location = new Point(315, 348);
            btnCustomerDelete.Name = "btnCustomerDelete";
            btnCustomerDelete.Size = new Size(94, 29);
            btnCustomerDelete.TabIndex = 15;
            btnCustomerDelete.Text = "Delete";
            btnCustomerDelete.UseVisualStyleBackColor = true;
            btnCustomerDelete.Click += btnCustomerDelete_Click;
            // 
            // btnCustomerEdit
            // 
            btnCustomerEdit.Location = new Point(185, 348);
            btnCustomerEdit.Name = "btnCustomerEdit";
            btnCustomerEdit.Size = new Size(94, 29);
            btnCustomerEdit.TabIndex = 14;
            btnCustomerEdit.Text = "Edit";
            btnCustomerEdit.UseVisualStyleBackColor = true;
            btnCustomerEdit.Click += btnCustomerEdit_Click;
            // 
            // btnCustomerAdd
            // 
            btnCustomerAdd.Location = new Point(59, 348);
            btnCustomerAdd.Name = "btnCustomerAdd";
            btnCustomerAdd.Size = new Size(94, 29);
            btnCustomerAdd.TabIndex = 13;
            btnCustomerAdd.Text = "Add";
            btnCustomerAdd.UseVisualStyleBackColor = true;
            btnCustomerAdd.Click += btnCustomerAdd_Click;
            // 
            // txtCustomerAddress
            // 
            txtCustomerAddress.Location = new Point(168, 196);
            txtCustomerAddress.Name = "txtCustomerAddress";
            txtCustomerAddress.Size = new Size(250, 27);
            txtCustomerAddress.TabIndex = 11;
            // 
            // txtCustomerMail
            // 
            txtCustomerMail.Location = new Point(168, 163);
            txtCustomerMail.Name = "txtCustomerMail";
            txtCustomerMail.Size = new Size(250, 27);
            txtCustomerMail.TabIndex = 10;
            // 
            // txtCustomerPhone
            // 
            txtCustomerPhone.Location = new Point(168, 126);
            txtCustomerPhone.Name = "txtCustomerPhone";
            txtCustomerPhone.Size = new Size(250, 27);
            txtCustomerPhone.TabIndex = 9;
            // 
            // txtCustomerName
            // 
            txtCustomerName.Location = new Point(168, 91);
            txtCustomerName.Name = "txtCustomerName";
            txtCustomerName.Size = new Size(250, 27);
            txtCustomerName.TabIndex = 8;
            // 
            // txtCustomerID
            // 
            txtCustomerID.Location = new Point(168, 51);
            txtCustomerID.Name = "txtCustomerID";
            txtCustomerID.Size = new Size(250, 27);
            txtCustomerID.TabIndex = 7;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Location = new Point(38, 212);
            label12.Name = "label12";
            label12.Size = new Size(53, 20);
            label12.TabIndex = 5;
            label12.Text = "Adress";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Location = new Point(38, 176);
            label11.Name = "label11";
            label11.Size = new Size(46, 20);
            label11.TabIndex = 4;
            label11.Text = "Email";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Location = new Point(38, 142);
            label10.Name = "label10";
            label10.Size = new Size(50, 20);
            label10.TabIndex = 3;
            label10.Text = "Phone";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Location = new Point(38, 107);
            label9.Name = "label9";
            label9.Size = new Size(49, 20);
            label9.TabIndex = 2;
            label9.Text = "Name";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Location = new Point(38, 67);
            label8.Name = "label8";
            label8.Size = new Size(107, 20);
            label8.TabIndex = 1;
            label8.Text = "CustomerCode";
            // 
            // listViewCustomers
            // 
            listViewCustomers.Location = new Point(485, 46);
            listViewCustomers.Name = "listViewCustomers";
            listViewCustomers.Size = new Size(284, 283);
            listViewCustomers.TabIndex = 0;
            listViewCustomers.UseCompatibleStateImageBehavior = false;
            listViewCustomers.View = View.Details;
            // 
            // Customers
            // 
            Customers.Controls.Add(btnUserDelete);
            Customers.Controls.Add(btnUserAdd);
            Customers.Controls.Add(txtUAID);
            Customers.Controls.Add(txtUAEmployeeID);
            Customers.Controls.Add(txtUAPassword);
            Customers.Controls.Add(label21);
            Customers.Controls.Add(txtUAUsername);
            Customers.Controls.Add(label16);
            Customers.Controls.Add(label15);
            Customers.Controls.Add(label14);
            Customers.Controls.Add(listViewUserAccounts);
            Customers.Location = new Point(4, 29);
            Customers.Name = "Customers";
            Customers.Padding = new Padding(3);
            Customers.Size = new Size(789, 417);
            Customers.TabIndex = 2;
            Customers.Text = "UserAccounts";
            Customers.UseVisualStyleBackColor = true;
            // 
            // btnUserDelete
            // 
            btnUserDelete.Location = new Point(224, 187);
            btnUserDelete.Name = "btnUserDelete";
            btnUserDelete.Size = new Size(94, 29);
            btnUserDelete.TabIndex = 8;
            btnUserDelete.Text = "Delete";
            btnUserDelete.UseVisualStyleBackColor = true;
            btnUserDelete.Click += btnUserDelete_Click;
            // 
            // btnUserAdd
            // 
            btnUserAdd.Location = new Point(89, 187);
            btnUserAdd.Name = "btnUserAdd";
            btnUserAdd.Size = new Size(94, 29);
            btnUserAdd.TabIndex = 7;
            btnUserAdd.Text = "Add";
            btnUserAdd.UseVisualStyleBackColor = true;
            btnUserAdd.Click += btnUserAdd_Click;
            // 
            // txtUAID
            // 
            txtUAID.Location = new Point(503, 72);
            txtUAID.Name = "txtUAID";
            txtUAID.Size = new Size(212, 27);
            txtUAID.TabIndex = 5;
            // 
            // txtUAEmployeeID
            // 
            txtUAEmployeeID.Location = new Point(503, 31);
            txtUAEmployeeID.Name = "txtUAEmployeeID";
            txtUAEmployeeID.Size = new Size(212, 27);
            txtUAEmployeeID.TabIndex = 5;
            // 
            // txtUAPassword
            // 
            txtUAPassword.Location = new Point(147, 72);
            txtUAPassword.Name = "txtUAPassword";
            txtUAPassword.Size = new Size(212, 27);
            txtUAPassword.TabIndex = 5;
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Location = new Point(388, 85);
            label21.Name = "label21";
            label21.Size = new Size(78, 20);
            label21.TabIndex = 3;
            label21.Text = "AccountID";
            // 
            // txtUAUsername
            // 
            txtUAUsername.Location = new Point(147, 28);
            txtUAUsername.Name = "txtUAUsername";
            txtUAUsername.Size = new Size(212, 27);
            txtUAUsername.TabIndex = 4;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Location = new Point(388, 44);
            label16.Name = "label16";
            label16.Size = new Size(96, 20);
            label16.TabIndex = 3;
            label16.Text = "EmployeesID";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Location = new Point(66, 85);
            label15.Name = "label15";
            label15.Size = new Size(70, 20);
            label15.TabIndex = 2;
            label15.Text = "Password";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Location = new Point(66, 34);
            label14.Name = "label14";
            label14.Size = new Size(38, 20);
            label14.TabIndex = 1;
            label14.Text = "User";
            // 
            // listViewUserAccounts
            // 
            listViewUserAccounts.Location = new Point(38, 242);
            listViewUserAccounts.Name = "listViewUserAccounts";
            listViewUserAccounts.Size = new Size(713, 121);
            listViewUserAccounts.TabIndex = 0;
            listViewUserAccounts.UseCompatibleStateImageBehavior = false;
            listViewUserAccounts.View = View.Details;
            // 
            // Products
            // 
            Products.Controls.Add(btnProductSearch);
            Products.Controls.Add(btnProductDelte);
            Products.Controls.Add(btnProductEdit);
            Products.Controls.Add(btnProductAdd);
            Products.Controls.Add(txtProductQuantity);
            Products.Controls.Add(txtProductPrice);
            Products.Controls.Add(txtProductID);
            Products.Controls.Add(txtProductName);
            Products.Controls.Add(label20);
            Products.Controls.Add(label19);
            Products.Controls.Add(label18);
            Products.Controls.Add(label17);
            Products.Controls.Add(listViewProducts);
            Products.Location = new Point(4, 29);
            Products.Name = "Products";
            Products.Padding = new Padding(3);
            Products.Size = new Size(789, 417);
            Products.TabIndex = 3;
            Products.Text = "Products";
            Products.UseVisualStyleBackColor = true;
            // 
            // btnProductSearch
            // 
            btnProductSearch.Location = new Point(658, 269);
            btnProductSearch.Name = "btnProductSearch";
            btnProductSearch.Size = new Size(94, 29);
            btnProductSearch.TabIndex = 12;
            btnProductSearch.Text = "Search";
            btnProductSearch.UseVisualStyleBackColor = true;
            // 
            // btnProductDelte
            // 
            btnProductDelte.Location = new Point(517, 269);
            btnProductDelte.Name = "btnProductDelte";
            btnProductDelte.Size = new Size(94, 29);
            btnProductDelte.TabIndex = 11;
            btnProductDelte.Text = "Delete";
            btnProductDelte.UseVisualStyleBackColor = true;
            btnProductDelte.Click += btnProductDelte_Click;
            // 
            // btnProductEdit
            // 
            btnProductEdit.Location = new Point(658, 181);
            btnProductEdit.Name = "btnProductEdit";
            btnProductEdit.Size = new Size(94, 29);
            btnProductEdit.TabIndex = 10;
            btnProductEdit.Text = "Edit";
            btnProductEdit.UseVisualStyleBackColor = true;
            // 
            // btnProductAdd
            // 
            btnProductAdd.Location = new Point(517, 181);
            btnProductAdd.Name = "btnProductAdd";
            btnProductAdd.Size = new Size(94, 29);
            btnProductAdd.TabIndex = 9;
            btnProductAdd.Text = "Add";
            btnProductAdd.UseVisualStyleBackColor = true;
            btnProductAdd.Click += btnProductAdd_Click;
            // 
            // txtProductQuantity
            // 
            txtProductQuantity.Location = new Point(191, 301);
            txtProductQuantity.Name = "txtProductQuantity";
            txtProductQuantity.Size = new Size(201, 27);
            txtProductQuantity.TabIndex = 8;
            // 
            // txtProductPrice
            // 
            txtProductPrice.Location = new Point(191, 256);
            txtProductPrice.Name = "txtProductPrice";
            txtProductPrice.Size = new Size(201, 27);
            txtProductPrice.TabIndex = 7;
            // 
            // txtProductID
            // 
            txtProductID.Location = new Point(191, 206);
            txtProductID.Name = "txtProductID";
            txtProductID.Size = new Size(201, 27);
            txtProductID.TabIndex = 6;
            // 
            // txtProductName
            // 
            txtProductName.Location = new Point(191, 161);
            txtProductName.Name = "txtProductName";
            txtProductName.Size = new Size(201, 27);
            txtProductName.TabIndex = 5;
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Location = new Point(71, 313);
            label20.Name = "label20";
            label20.Size = new Size(119, 20);
            label20.TabIndex = 4;
            label20.Text = "Quantity in stock";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Location = new Point(71, 268);
            label19.Name = "label19";
            label19.Size = new Size(41, 20);
            label19.TabIndex = 3;
            label19.Text = "Price";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Location = new Point(71, 218);
            label18.Name = "label18";
            label18.Size = new Size(44, 20);
            label18.TabIndex = 2;
            label18.Text = "Code";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Location = new Point(71, 173);
            label17.Name = "label17";
            label17.Size = new Size(49, 20);
            label17.TabIndex = 1;
            label17.Text = "Name";
            // 
            // listViewProducts
            // 
            listViewProducts.Location = new Point(34, 16);
            listViewProducts.Name = "listViewProducts";
            listViewProducts.Size = new Size(705, 121);
            listViewProducts.TabIndex = 0;
            listViewProducts.UseCompatibleStateImageBehavior = false;
            listViewProducts.View = View.List;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(cmbProducts);
            tabPage1.Controls.Add(cmbCustomers);
            tabPage1.Controls.Add(btnDeleteItem);
            tabPage1.Controls.Add(btnEditItem);
            tabPage1.Controls.Add(this.btnAddItem);
            tabPage1.Controls.Add(btnCreateInvoice);
            tabPage1.Controls.Add(listViewInvoiceItems);
            tabPage1.Controls.Add(txtInvoiceQuantity);
            tabPage1.Controls.Add(label13);
            tabPage1.Controls.Add(label23);
            tabPage1.Controls.Add(label22);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(789, 417);
            tabPage1.TabIndex = 4;
            tabPage1.Text = "Sale invoice";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // btnDeleteItem
            // 
            btnDeleteItem.Location = new Point(498, 113);
            btnDeleteItem.Name = "btnDeleteItem";
            btnDeleteItem.Size = new Size(94, 29);
            btnDeleteItem.TabIndex = 44;
            btnDeleteItem.Text = "Delete";
            btnDeleteItem.UseVisualStyleBackColor = true;
            // 
            // btnEditItem
            // 
            btnEditItem.Location = new Point(604, 53);
            btnEditItem.Name = "btnEditItem";
            btnEditItem.Size = new Size(94, 29);
            btnEditItem.TabIndex = 42;
            btnEditItem.Text = "Edit";
            btnEditItem.UseVisualStyleBackColor = true;
            // 
            // btnAddItem
            // 
            this.btnAddItem.Location = new Point(498, 53);
            this.btnAddItem.Name = "btnAddItem";
            this.btnAddItem.Size = new Size(94, 29);
            this.btnAddItem.TabIndex = 43;
            this.btnAddItem.Text = "Add";
            this.btnAddItem.UseVisualStyleBackColor = true;
            // 
            // btnCreateInvoice
            // 
            btnCreateInvoice.Location = new Point(78, 337);
            btnCreateInvoice.Name = "btnCreateInvoice";
            btnCreateInvoice.Size = new Size(122, 29);
            btnCreateInvoice.TabIndex = 41;
            btnCreateInvoice.Text = "Create Invoice";
            btnCreateInvoice.UseVisualStyleBackColor = true;
            // 
            // listViewInvoiceItems
            // 
            listViewInvoiceItems.Location = new Point(78, 210);
            listViewInvoiceItems.Name = "listViewInvoiceItems";
            listViewInvoiceItems.Size = new Size(633, 121);
            listViewInvoiceItems.TabIndex = 40;
            listViewInvoiceItems.UseCompatibleStateImageBehavior = false;
            listViewInvoiceItems.View = View.Details;
            // 
            // txtInvoiceQuantity
            // 
            txtInvoiceQuantity.Location = new Point(231, 119);
            txtInvoiceQuantity.Name = "txtInvoiceQuantity";
            txtInvoiceQuantity.Size = new Size(200, 27);
            txtInvoiceQuantity.TabIndex = 38;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Location = new Point(84, 89);
            label13.Name = "label13";
            label13.Size = new Size(63, 20);
            label13.TabIndex = 34;
            label13.Text = "Product:";
            // 
            // label23
            // 
            label23.AutoSize = true;
            label23.Location = new Point(84, 125);
            label23.Name = "label23";
            label23.Size = new Size(48, 20);
            label23.TabIndex = 35;
            label23.Text = "Many:";
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Location = new Point(84, 56);
            label22.Name = "label22";
            label22.Size = new Size(115, 20);
            label22.TabIndex = 36;
            label22.Text = "CustomerName:";
            // 
            // cmbCustomers
            // 
            cmbCustomers.FormattingEnabled = true;
            cmbCustomers.Location = new Point(231, 48);
            cmbCustomers.Name = "cmbCustomers";
            cmbCustomers.Size = new Size(200, 28);
            cmbCustomers.TabIndex = 45;
            // 
            // cmbProducts
            // 
            cmbProducts.FormattingEnabled = true;
            cmbProducts.Location = new Point(231, 85);
            cmbProducts.Name = "cmbProducts";
            cmbProducts.Size = new Size(200, 28);
            cmbProducts.TabIndex = 45;
            // 
            // AdminForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(lvProduct);
            Name = "AdminForm";
            Text = "AdminForm";
            Load += AdminForm_Load;
            lvProduct.ResumeLayout(false);
            Employees.ResumeLayout(false);
            Employees.PerformLayout();
            UserAccounts.ResumeLayout(false);
            UserAccounts.PerformLayout();
            Customers.ResumeLayout(false);
            Customers.PerformLayout();
            Products.ResumeLayout(false);
            Products.PerformLayout();
            tabPage1.ResumeLayout(false);
            tabPage1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl lvProduct;
        private TabPage Employees;
        private ListView listViewEmployees;
        private Button btnEmployeesDelete;
        private Button btnEmployeesEdit;
        private Button btnEmployeesAdd;
        private TextBox txtEmployeesPhone;
        private TextBox txtEmployeesEmail;
        private TextBox txtEmployeesPosition;
        private TextBox txtEmployeesName;
        private TextBox txtEmployeesID;
        private Label label7;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private Label label1;
        private TabPage UserAccounts;
        private Button btnCustomerDelete;
        private Button btnCustomerEdit;
        private Button btnCustomerAdd;
        private TextBox txtCustomerAddress;
        private TextBox txtCustomerMail;
        private TextBox txtCustomerPhone;
        private TextBox txtCustomerName;
        private TextBox txtCustomerID;
        private Label label12;
        private Label label11;
        private Label label10;
        private Label label9;
        private Label label8;
        private ListView listViewCustomers;
        private TabPage Customers;
        private Button btnUserDelete;
        private Button btnUserAdd;
        private TextBox txtUAID;
        private TextBox txtUAEmployeeID;
        private TextBox txtUAPassword;
        private Label label21;
        private TextBox txtUAUsername;
        private Label label16;
        private Label label15;
        private Label label14;
        private ListView listViewUserAccounts;
        private TabPage Products;
        private Button btnProductSearch;
        private Button btnProductDelte;
        private Button btnProductEdit;
        private Button btnProductAdd;
        private TextBox txtProductQuantity;
        private TextBox txtProductPrice;
        private TextBox txtProductID;
        private TextBox txtProductName;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private ListView listViewProducts;
        private TabPage tabPage1;
        private Button btnDeleteItem;
        private Button btnEditItem;
        private Button button2;
        private Button btnCreateInvoice;
        private ListView listViewInvoiceItems;
        private TextBox ProductID;
        private TextBox txtInvoiceQuantity;
        private Label label13;
        private Label label23;
        private TextBox txtInvoiceCustomerName;
        private Label label22;
        private ComboBox cmbProducts;
        private ComboBox cmbCustomers;
    }
}