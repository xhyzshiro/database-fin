﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testagain
{
    public partial class SaleForm : Form
    {
        SqlConnection conn = new SqlConnection(@"Server=SHIRO\SQLEXPRESS;Database=StoreXDB;Trusted_Connection=True;");
        private int EmployeeID;  // nhân viên đang đăng nhập

        public SaleForm()
        {
            InitializeComponent();
            EmployeeID = EmployeeID;
        }

        private void SaleForm_Load(object sender, EventArgs e)
        {
            LoadProducts();
            LoadCustomers();
            LoadMyOrders();
            SetupListViews();
        }
        private void LoadProducts()
        {
            lvProduct.Items.Clear();
            string sql = "SELECT ProductID, ProductName, Price, Quantity FROM Products";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["ProductID"].ToString());
                item.SubItems.Add(reader["ProductName"].ToString());
                item.SubItems.Add(reader["Price"].ToString());
                item.SubItems.Add(reader["Quantity"].ToString());
                lvProduct.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }
        private void LoadCustomers()
        {
            lvCustomer.Items.Clear();
            string sql = "SELECT CustomerID, CustomerName, Phone, Address FROM Customers";
            SqlCommand cmd = new SqlCommand(sql, conn);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["CustomerID"].ToString());
                item.SubItems.Add(reader["CustomerName"].ToString());
                item.SubItems.Add(reader["Phone"].ToString());
                item.SubItems.Add(reader["Address"].ToString());
                lvCustomer.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }

        private void btnCustomerAdd_Click(object sender, EventArgs e)
        {
            string sql = "INSERT INTO Customers(CustomerName, Phone, Address) VALUES(@name,@phone,@addr)";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@phone", txtCustomerPhone.Text);
            cmd.Parameters.AddWithValue("@addr", txtCustomerAddress.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }

        private void btnCustomerEdit_Click(object sender, EventArgs e)
        {
            string sql = "UPDATE Customers SET CustomerName=@name, Phone=@phone, Address=@addr WHERE CustomerID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtCustomerID.Text));
            cmd.Parameters.AddWithValue("@name", txtCustomerName.Text);
            cmd.Parameters.AddWithValue("@phone", txtCustomerPhone.Text);
            cmd.Parameters.AddWithValue("@addr", txtCustomerAddress.Text);

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }

        private void btnCustomerDelete_Click(object sender, EventArgs e)
        {
            string sql = "DELETE FROM Customers WHERE CustomerID=@id";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@id", int.Parse(txtCustomerID.Text));

            conn.Open();
            cmd.ExecuteNonQuery();
            conn.Close();

            LoadCustomers();
        }

        private void btnCreateInvoice_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(txtCustomerID.Text))
            {
                MessageBox.Show("Vui lòng chọn khách hàng.");
                return;
            }
            if (lvSaleInvoice.Items.Count == 0)
            {
                MessageBox.Show("Vui lòng thêm sản phẩm vào hóa đơn.");
                return;
            }

            // Biến để lưu ID hóa đơn
            int invoiceID = 0;

            // === BƯỚC 1: TẠO HÓA ĐƠN VÀ LẤY ID TRẢ VỀ ===
            try
            {
                string sqlInvoice = "INSERT INTO SalesInvoices(EmployeeID, CustomerID) OUTPUT INSERTED.InvoiceID VALUES(@eid,@cid)";
                SqlCommand cmd = new SqlCommand(sqlInvoice, conn);
                cmd.Parameters.AddWithValue("@eid", EmployeeID); // Giả sử biến EmployeeID đã có giá trị đúng
                cmd.Parameters.AddWithValue("@cid", int.Parse(txtCustomerID.Text));

                conn.Open();
                invoiceID = (int)cmd.ExecuteScalar(); // Lấy ID hóa đơn vừa tạo
                conn.Close(); // Đóng kết nối ngay sau khi lấy được ID
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tạo hóa đơn chính: " + ex.Message);
                if (conn.State == ConnectionState.Open) // Đảm bảo kết nối được đóng nếu có lỗi
                {
                    conn.Close();
                }
                return; // Dừng lại nếu không tạo được hóa đơn
            }

            // Nếu không lấy được ID hóa đơn thì dừng lại
            if (invoiceID == 0)
            {
                MessageBox.Show("Không thể tạo được hóa đơn mới.");
                return;
            }

            // === BƯỚC 2: THÊM CHI TIẾT HÓA ĐƠN VÀ CẬP NHẬT KHO ===
            try
            {
                conn.Open(); // Mở lại kết nối để thực hiện vòng lặp

                // lặp qua từng sản phẩm trong ListView giỏ hàng
                foreach (ListViewItem item in lvSaleInvoice.Items)
                {
                    // Thêm chi tiết hóa đơn
                    string sqlDetail = "INSERT INTO SalesDetails(InvoiceID, ProductID, Quantity, UnitPrice) VALUES(@inv,@pid,@qty,@price)";
                    SqlCommand cmd2 = new SqlCommand(sqlDetail, conn);
                    cmd2.Parameters.AddWithValue("@inv", invoiceID);

                    // Lấy dữ liệu từ các cột của ListViewItem
                    cmd2.Parameters.AddWithValue("@pid", int.Parse(item.SubItems[0].Text));   // Cột 0: ProductID
                    cmd2.Parameters.AddWithValue("@qty", int.Parse(item.SubItems[2].Text));   // Cột 2: Quantity
                    cmd2.Parameters.AddWithValue("@price", decimal.Parse(item.SubItems[3].Text)); // Cột 3: UnitPrice
                    cmd2.ExecuteNonQuery();

                    // Cập nhật số lượng tồn kho
                    string sqlUpdateStock = "UPDATE Products SET Quantity = Quantity - @qty WHERE ProductID = @pid";
                    SqlCommand cmd3 = new SqlCommand(sqlUpdateStock, conn);
                    cmd3.Parameters.AddWithValue("@qty", int.Parse(item.SubItems[2].Text));
                    cmd3.Parameters.AddWithValue("@pid", int.Parse(item.SubItems[0].Text));
                    cmd3.ExecuteNonQuery();
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi thêm chi tiết hóa đơn hoặc cập nhật kho: " + ex.Message);
            }
            finally // Khối finally đảm bảo conn.Close() luôn được gọi
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close(); // Đóng kết nối sau khi vòng lặp kết thúc
                }
            }

            MessageBox.Show("Tạo hóa đơn thành công!");

            // Tải lại dữ liệu
            LoadMyOrders();
            LoadProducts();
            lvSaleInvoice.Items.Clear(); // Xóa giỏ hàng sau khi tạo hóa đơn
        }
        private void LoadMyOrders()
        {
            lvMyOrder.Items.Clear();
            string sql = "SELECT InvoiceID, CustomerID, InvoiceDate FROM SalesInvoices WHERE EmployeeID=@eid";
            SqlCommand cmd = new SqlCommand(sql, conn);
            cmd.Parameters.AddWithValue("@eid", EmployeeID);
            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["InvoiceID"].ToString());
                item.SubItems.Add(reader["CustomerID"].ToString());
                item.SubItems.Add(Convert.ToDateTime(reader["InvoiceDate"]).ToString("yyyy-MM-dd"));
                lvMyOrder.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }
        private void SetupListViews()
        {
            // Products
            lvProduct.View = View.Details;
            lvProduct.FullRowSelect = true;
            lvProduct.Columns.Clear();
            lvProduct.Columns.Add("ProductID", 80);
            lvProduct.Columns.Add("ProductName", 150);
            lvProduct.Columns.Add("Price", 100);
            lvProduct.Columns.Add("Quantity", 100);
        }
    }
}
