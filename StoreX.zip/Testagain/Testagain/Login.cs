﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testagain
{
    public partial class Login : Form
    {
        string connStr = @"Server=SHIRO\SQLEXPRESS;Database=StoreXDB;Trusted_Connection=True;TrustServerCertificate=True;";
        public Login()
        {
            InitializeComponent();
            EnsureDefaultUsers();
        }

        private void Login_Load(object sender, EventArgs e)
        {

        }
        private void EnsureDefaultUsers()
        {
            // Sử dụng khối 'using' sẽ tự động đóng kết nối, kể cả khi có lỗi.
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                conn.Open();

                // --- Thêm nhân viên và tài khoản Admin ---
                string checkAdmin = "SELECT COUNT(*) FROM UserAccounts WHERE Username='admin'";
                SqlCommand cmdCheck = new SqlCommand(checkAdmin, conn);
                int countAdmin = (int)cmdCheck.ExecuteScalar();

                if (countAdmin == 0)
                {
                    // Thêm nhân viên Admin
                    string sqlEmp = "INSERT INTO Employees(EmployeeName, Role) OUTPUT INSERTED.EmployeeID VALUES('Administrator','Admin')";
                    SqlCommand cmdEmp = new SqlCommand(sqlEmp, conn);
                    int empId = (int)cmdEmp.ExecuteScalar();

                    // Thêm tài khoản Admin
                    // SỬA LỖI: Thay thế 'PasswordHash' bằng 'Password' (hoặc tên cột đúng trong DB của bạn)
                    string sqlUser = "INSERT INTO UserAccounts(EmployeeID, Username, Password) VALUES(@eid, 'admin', 'admin123')";
                    SqlCommand cmdUser = new SqlCommand(sqlUser, conn);
                    cmdUser.Parameters.AddWithValue("@eid", empId);
                    cmdUser.ExecuteNonQuery();
                }

                // --- Thêm nhân viên và tài khoản Sales ---
                string checkSales = "SELECT COUNT(*) FROM UserAccounts WHERE Username='sales'";
                cmdCheck = new SqlCommand(checkSales, conn);
                int countSales = (int)cmdCheck.ExecuteScalar();

                if (countSales == 0)
                {
                    string sqlEmp = "INSERT INTO Employees(EmployeeName, Role) OUTPUT INSERTED.EmployeeID VALUES('John Sales','Sales')";
                    SqlCommand cmdEmp = new SqlCommand(sqlEmp, conn);
                    int empId = (int)cmdEmp.ExecuteScalar();

                    // SỬA LỖI: Thay thế 'PasswordHash' bằng 'Password'
                    string sqlUser = "INSERT INTO UserAccounts(EmployeeID, Username, Password) VALUES(@eid, 'sales', 'sales123')";
                    SqlCommand cmdUser = new SqlCommand(sqlUser, conn);
                    cmdUser.Parameters.AddWithValue("@eid", empId);
                    cmdUser.ExecuteNonQuery();
                }

                // --- Thêm nhân viên và tài khoản Warehouse ---
                string checkWarehouse = "SELECT COUNT(*) FROM UserAccounts WHERE Username='warehouse'";
                cmdCheck = new SqlCommand(checkWarehouse, conn);
                int countWarehouse = (int)cmdCheck.ExecuteScalar();

                if (countWarehouse == 0)
                {
                    string sqlEmp = "INSERT INTO Employees(EmployeeName, Role) OUTPUT INSERTED.EmployeeID VALUES('Jane Warehouse','Warehouse')";
                    SqlCommand cmdEmp = new SqlCommand(sqlEmp, conn);
                    int empId = (int)cmdEmp.ExecuteScalar();

                    // SỬA LỖI: Thay thế 'PasswordHash' bằng 'Password'
                    string sqlUser = "INSERT INTO UserAccounts(EmployeeID, Username, Password) VALUES(@eid, 'warehouse', 'warehouse123')";
                    SqlCommand cmdUser = new SqlCommand(sqlUser, conn);
                    cmdUser.Parameters.AddWithValue("@eid", empId);
                    cmdUser.ExecuteNonQuery();
                }

                // Không cần conn.Close() ở đây vì 'using' đã tự xử lý.
            }
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text.Trim();

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Please enter both Username and Password!");
                return;
            }

            using (SqlConnection conn = new SqlConnection(connStr))
            {
                try
                {
                    conn.Open();
                    // SỬA LỖI: Thay thế 'PasswordHash' bằng 'Password'
                    string query = @"SELECT e.Role 
                                     FROM UserAccounts u
                                     JOIN Employees e ON u.EmployeeID = e.EmployeeID
                                     WHERE u.Username=@u AND u.Password=@p";

                    SqlCommand cmd = new SqlCommand(query, conn);
                    cmd.Parameters.AddWithValue("@u", username);
                    cmd.Parameters.AddWithValue("@p", password);

                    var role = cmd.ExecuteScalar();

                    if (role != null)
                    {
                        string roleName = role.ToString();
                        this.Hide();

                        if (roleName == "Admin")
                            new AdminForm().Show();
                        else if (roleName == "Sales")
                            new SaleForm().Show();
                        else if (roleName == "Warehouse")
                            new WareHouseForm().Show(); // Giả sử tên Form là WareHouseForm
                        else
                        {
                            MessageBox.Show("Role not recognized!");
                            this.Show(); // Hiện lại form login nếu role không hợp lệ
                        }
                    }
                    else
                    {
                        MessageBox.Show("Invalid username or password!");
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Database connection error: " + ex.Message);
                }
            }
        }
    }
}
