﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Testagain
{
    public partial class WareHouseForm : Form
    {
        SqlConnection conn = new SqlConnection(@"Server=SHIRO\SQLEXPRESS;Database=StoreXDB;Trusted_Connection=True;");
        public WareHouseForm()
        {
            InitializeComponent();
        }

        private void WareHouseForm_Load(object sender, EventArgs e)
        {
            SetupListViews();
            LoadProducts();
            LoadImports();
            LoadProductCombo();
        }
        private void SetupListViews()
        {
            // Products
            lvProduct.View = View.Details;
            lvProduct.FullRowSelect = true;
            lvProduct.Columns.Clear();
            lvProduct.Columns.Add("ProductID", 80);
            lvProduct.Columns.Add("ProductName", 150);
            lvProduct.Columns.Add("Price", 100);
            lvProduct.Columns.Add("Quantity", 100);

            // Imports
            lvImports.View = View.Details;
            lvImports.FullRowSelect = true;
            lvImports.Columns.Clear();
            lvImports.Columns.Add("ImportID", 80);
            lvImports.Columns.Add("ProductName", 150);
            lvImports.Columns.Add("Quantity", 100);
            lvImports.Columns.Add("ImportDate", 150);
        }
        private void LoadProducts()
        {
            lvProduct.Items.Clear();
            string sql = "SELECT * FROM Products";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["ProductID"].ToString());
                item.SubItems.Add(reader["ProductName"].ToString());
                item.SubItems.Add(reader["Price"].ToString());
                item.SubItems.Add(reader["Quantity"].ToString());
                lvProduct.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }
        
        private void LoadImports()
        {
            lvImports.Items.Clear();
            string sql = @"SELECT I.ImportID, P.ProductName, I.Quantity, I.ImportDate
                           FROM ProductImports I
                           JOIN Products P ON I.ProductID = P.ProductID";
            SqlCommand cmd = new SqlCommand(sql, conn);

            conn.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            while (reader.Read())
            {
                ListViewItem item = new ListViewItem(reader["ImportID"].ToString());
                item.SubItems.Add(reader["ProductName"].ToString());
                item.SubItems.Add(reader["Quantity"].ToString());
                item.SubItems.Add(Convert.ToDateTime(reader["ImportDate"]).ToString("yyyy-MM-dd HH:mm"));
                lvImports.Items.Add(item);
            }
            reader.Close();
            conn.Close();
        }
        private void LoadProductCombo()
        {
            SqlDataAdapter da = new SqlDataAdapter("SELECT ProductID, ProductName FROM Products", conn);
            DataTable dt = new DataTable();
            da.Fill(dt);

            cbProduct.DataSource = dt;
            cbProduct.DisplayMember = "ProductName";
            cbProduct.ValueMember = "ProductID";
        }

        private void btnImportAdd_Click(object sender, EventArgs e)
        {
            if (cbProduct.SelectedValue == null || string.IsNullOrWhiteSpace(txtQty.Text))
            {
                MessageBox.Show("Please select product and enter quantity!");
                return;
            }

            int pid = Convert.ToInt32(cbProduct.SelectedValue);
            int qty = Convert.ToInt32(txtQty.Text);

            conn.Open();

            // Thêm vào tblProductImports
            string sqlImport = "INSERT INTO ProductImports(ProductID, Quantity) VALUES(@pid,@qty)";
            SqlCommand cmd1 = new SqlCommand(sqlImport, conn);
            cmd1.Parameters.AddWithValue("@pid", pid);
            cmd1.Parameters.AddWithValue("@qty", qty);
            cmd1.ExecuteNonQuery();

            // Update tồn kho
            string sqlUpdate = "UPDATE Products SET Quantity = Quantity + @qty WHERE ProductID=@pid";
            SqlCommand cmd2 = new SqlCommand(sqlUpdate, conn);
            cmd2.Parameters.AddWithValue("@pid", pid);
            cmd2.Parameters.AddWithValue("@qty", qty);
            cmd2.ExecuteNonQuery();

            conn.Close();

            MessageBox.Show("Product imported successfully!");
            LoadProducts();
            LoadImports();
        }

        private void btnImportDelete_Click(object sender, EventArgs e)
        {
            if (lvImports.SelectedItems.Count == 0) return;

            int importID = Convert.ToInt32(lvImports.SelectedItems[0].SubItems[0].Text);
            int qty = Convert.ToInt32(lvImports.SelectedItems[0].SubItems[2].Text);
            string productName = lvImports.SelectedItems[0].SubItems[1].Text;

            DialogResult dr = MessageBox.Show(
                $"Are you sure to delete Import #{importID} for {productName}?",
                "Confirm", MessageBoxButtons.YesNo);

            if (dr == DialogResult.Yes)
            {
                conn.Open();

                // Lấy ProductID từ import record
                SqlCommand getPid = new SqlCommand(
                    "SELECT ProductID FROM ProductImports WHERE ImportID=@id", conn);
                getPid.Parameters.AddWithValue("@id", importID);
                int pid = (int)getPid.ExecuteScalar();

                // Xóa record import
                SqlCommand cmdDel = new SqlCommand("DELETE FROM ProductImports WHERE ImportID=@id", conn);
                cmdDel.Parameters.AddWithValue("@id", importID);
                cmdDel.ExecuteNonQuery();

                // Giảm tồn kho
                SqlCommand cmdUpd = new SqlCommand(
                    "UPDATE Products SET Quantity = Quantity - @qty WHERE ProductID=@pid", conn);
                cmdUpd.Parameters.AddWithValue("@qty", qty);
                cmdUpd.Parameters.AddWithValue("@pid", pid);
                cmdUpd.ExecuteNonQuery();

                conn.Close();

                MessageBox.Show("Import deleted and stock updated!");
                LoadProducts();
                LoadImports();
            }
        }

        private void Imports_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
