﻿namespace Testagain
{
    partial class WareHouseForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            tabControl1 = new TabControl();
            tabPage1 = new TabPage();
            lvProduct = new ListView();
            tabPage2 = new TabPage();
            lvImports = new ListView();
            btnReport = new Button();
            txtQty = new TextBox();
            cbProduct = new ComboBox();
            btnImportDelete = new Button();
            btnImportAdd = new Button();
            label4 = new Label();
            label1 = new Label();
            tabControl1.SuspendLayout();
            tabPage1.SuspendLayout();
            tabPage2.SuspendLayout();
            SuspendLayout();
            // 
            // tabControl1
            // 
            tabControl1.Controls.Add(tabPage1);
            tabControl1.Controls.Add(tabPage2);
            tabControl1.Location = new Point(-1, -2);
            tabControl1.Name = "tabControl1";
            tabControl1.SelectedIndex = 0;
            tabControl1.Size = new Size(801, 454);
            tabControl1.TabIndex = 0;
            // 
            // tabPage1
            // 
            tabPage1.Controls.Add(lvProduct);
            tabPage1.Location = new Point(4, 29);
            tabPage1.Name = "tabPage1";
            tabPage1.Padding = new Padding(3);
            tabPage1.Size = new Size(793, 421);
            tabPage1.TabIndex = 0;
            tabPage1.Text = "Products";
            tabPage1.UseVisualStyleBackColor = true;
            // 
            // lvProduct
            // 
            lvProduct.Location = new Point(80, 83);
            lvProduct.Name = "lvProduct";
            lvProduct.Size = new Size(609, 219);
            lvProduct.TabIndex = 1;
            lvProduct.UseCompatibleStateImageBehavior = false;
            lvProduct.View = View.Tile;
            // 
            // tabPage2
            // 
            tabPage2.Controls.Add(lvImports);
            tabPage2.Controls.Add(btnReport);
            tabPage2.Controls.Add(txtQty);
            tabPage2.Controls.Add(cbProduct);
            tabPage2.Controls.Add(btnImportDelete);
            tabPage2.Controls.Add(btnImportAdd);
            tabPage2.Controls.Add(label4);
            tabPage2.Controls.Add(label1);
            tabPage2.Location = new Point(4, 29);
            tabPage2.Name = "tabPage2";
            tabPage2.Padding = new Padding(3);
            tabPage2.Size = new Size(793, 421);
            tabPage2.TabIndex = 1;
            tabPage2.Text = "Product Imports";
            tabPage2.UseVisualStyleBackColor = true;
            // 
            // lvImports
            // 
            lvImports.Location = new Point(76, 253);
            lvImports.Name = "lvImports";
            lvImports.Size = new Size(608, 121);
            lvImports.TabIndex = 16;
            lvImports.UseCompatibleStateImageBehavior = false;
            lvImports.View = View.Details;
            // 
            // btnReport
            // 
            btnReport.Location = new Point(459, 197);
            btnReport.Name = "btnReport";
            btnReport.Size = new Size(94, 29);
            btnReport.TabIndex = 15;
            btnReport.Text = "report";
            btnReport.UseVisualStyleBackColor = true;
            // 
            // txtQty
            // 
            txtQty.Location = new Point(254, 126);
            txtQty.Name = "txtQty";
            txtQty.Size = new Size(260, 27);
            txtQty.TabIndex = 14;
            // 
            // cbProduct
            // 
            cbProduct.FormattingEnabled = true;
            cbProduct.Location = new Point(253, 46);
            cbProduct.Name = "cbProduct";
            cbProduct.Size = new Size(261, 28);
            cbProduct.TabIndex = 13;
            // 
            // btnImportDelete
            // 
            btnImportDelete.Location = new Point(276, 197);
            btnImportDelete.Name = "btnImportDelete";
            btnImportDelete.Size = new Size(94, 29);
            btnImportDelete.TabIndex = 11;
            btnImportDelete.Text = "Delete";
            btnImportDelete.UseVisualStyleBackColor = true;
            btnImportDelete.Click += btnImportDelete_Click;
            // 
            // btnImportAdd
            // 
            btnImportAdd.Location = new Point(102, 197);
            btnImportAdd.Name = "btnImportAdd";
            btnImportAdd.Size = new Size(94, 29);
            btnImportAdd.TabIndex = 9;
            btnImportAdd.Text = "Add";
            btnImportAdd.UseVisualStyleBackColor = true;
            btnImportAdd.Click += btnImportAdd_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(76, 129);
            label4.Name = "label4";
            label4.Size = new Size(119, 20);
            label4.TabIndex = 3;
            label4.Text = "Quantity in stock";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(76, 54);
            label1.Name = "label1";
            label1.Size = new Size(63, 20);
            label1.TabIndex = 0;
            label1.Text = "Product:";
            // 
            // WareHouseForm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(tabControl1);
            Name = "WareHouseForm";
            Text = "WareHouse";
            Load += WareHouseForm_Load;
            tabControl1.ResumeLayout(false);
            tabPage1.ResumeLayout(false);
            tabPage2.ResumeLayout(false);
            tabPage2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private TabControl tabControl1;
        private TabPage tabPage1;
        private TabPage tabPage2;
        private Label label4;
        private Label label1;
        private Button btnImportDelete;
        private Button btnImportAdd;
        private ComboBox cbProduct;
        private TextBox txtQty;
        private Button btnReport;
        private ListView lvImports;
        private ListView lvProduct;
    }
}